namespace CrgAutomation;

public abstract record GameEvent(
    int Tick
);

public record LineupClockStartedEvent(
    int Tick
) : GameEvent(Tick);

public record JamStartedEvent(
    int Tick,
    OnTrackTeam HomeTeam,
    OnTrackTeam AwayTeam
) : GameEvent(Tick);

public record JamAdvancedEvent(
    int Tick
) : GameEvent(Tick);

public record SkaterLinedUpEvent(
    int Tick,
    string Number,
    Position Position,
    TeamType Team
) : GameEvent(Tick);

public record SkaterSentToBoxEvent(
    int Tick,
    string PenaltyCode,
    TeamType Team,
    string SkaterNumber
) : GameEvent(Tick);

public record SkaterReleasedFromBoxEvent(
    int Tick,
    TeamType Team,
    string SkaterNumber
) : GameEvent(Tick);

public record SkaterSatInBoxEvent(
    int Tick,
    TeamType Team,
    string SkaterNumber
) : GameEvent(Tick);

public record LeadEarnedEvent(
    int Tick,
    TeamType Team
) : GameEvent(Tick);

public record LeadLostEvent(
    int Tick,
    TeamType Team
) : GameEvent(Tick);

public record JamCalledEvent(
    int Tick
) : GameEvent(Tick);

public record InitialTripCompletedEvent(
    int Tick,
    TeamType Team
) : GameEvent(Tick);

public record PointsAwardedEvent(
    int Tick,
    TeamType Team,
    int Points
) : GameEvent(Tick);