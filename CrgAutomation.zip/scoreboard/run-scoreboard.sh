#!/bin/bash

rm -r ./crg-scoreboard_2023.7
unzip ./crg-scoreboard_v2023.7.zip
cd ./crg-scoreboard_v2023.7
./scoreboard.sh --nogui
